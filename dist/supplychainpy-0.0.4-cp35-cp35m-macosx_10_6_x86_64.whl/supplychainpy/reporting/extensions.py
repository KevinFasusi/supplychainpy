from flask.ext.restful import Api

rest_api = Api()

