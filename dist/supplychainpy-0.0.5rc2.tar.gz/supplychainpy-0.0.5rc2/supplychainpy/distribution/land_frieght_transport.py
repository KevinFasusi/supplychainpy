class FreightTruck:
    def __init__(self):
        self.make
        self.model
        self.mpg
        self.weight

