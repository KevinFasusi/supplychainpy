# Copyright (C) 20015-2016 the Supplychainpy authors and contributors
# <see AUTHORS file>