from supplychainpy.reporting.blueprints.recommendations.views import recommendations, recommended
