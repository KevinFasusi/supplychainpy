from supplychainpy.reporting.blueprints.bot.views import bot


