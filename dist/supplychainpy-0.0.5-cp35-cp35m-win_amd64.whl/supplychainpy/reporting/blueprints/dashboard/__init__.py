from supplychainpy.reporting.blueprints.dashboard.views import (dashboard,
                                                                sku_detail,
                                                                get_classification_summary,
                                                                abxyz,top_shortages,
                                                                top_excess,
                                                                sku,
                                                                total_inventory,
                                                                currency)
